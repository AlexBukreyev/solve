<div class="fl-builder-bar">
	<div class="fl-builder-bar-content">
		<?php FLBuilder::render_ui_bar_title(); ?>
		<?php FLBuilder::render_ui_bar_buttons(); ?>
		<div class="fl-clear"></div>
	</div>
</div>