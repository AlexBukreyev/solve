(function($) {
	
	$(function() {
		$('.fl-embed-video').fitVids();
	});
	
})(jQuery);